package com.noqoush.adfalcon.adgallery.model;

public class AdType extends Ad{

	public AdType(String title, String value) {
		super(title, "R_AdType", value);
	}

}
