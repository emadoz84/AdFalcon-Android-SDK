package com.noqoush.adfalcon.adgallery.model;


public class AdUnitSize extends Ad{

	//private Vector<AdType> types = new Vector<AdType>();
	
	public AdUnitSize(String title, String value) {
		super(title, "R_AS", value);
	}
	/*
	public void setTypes(Vector<AdType> types){
		this.types = types;
	}

	public Vector<AdType> getTypes(){
		return types;
	}*/
}
